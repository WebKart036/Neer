package com.coolappstore.everlastingandroidtweak.features.appupdater.data

import com.google.gson.Gson
import com.coolappstore.everlastingandroidtweak.features.appupdater.domain.github.GitHubRelease
import com.coolappstore.everlastingandroidtweak.features.appupdater.domain.github.GitHubRepo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class GitHubRepository {
    private val gson = Gson()

    suspend fun getRepoInfo(owner: String, repo: String, token: String? = null): GitHubRepo? =
        withContext(Dispatchers.IO) {
            try {
                val url = URL("https://api.github.com/repos/$owner/$repo")
                val connection = url.openConnection() as HttpURLConnection
                if (token != null) connection.setRequestProperty("Authorization", "Bearer $token")
                when (connection.responseCode) {
                    200 -> gson.fromJson(connection.inputStream.bufferedReader().readText(), GitHubRepo::class.java)
                    403, 429 -> throw Exception("RATE_LIMIT")
                    else -> null
                }
            } catch (e: Exception) {
                if (e.message == "RATE_LIMIT") throw e
                null
            }
        }

    suspend fun getLatestRelease(owner: String, repo: String, token: String? = null): GitHubRelease? =
        withContext(Dispatchers.IO) {
            try {
                val url = URL("https://api.github.com/repos/$owner/$repo/releases/latest")
                val connection = url.openConnection() as HttpURLConnection
                if (token != null) connection.setRequestProperty("Authorization", "Bearer $token")
                when (connection.responseCode) {
                    200 -> gson.fromJson(connection.inputStream.bufferedReader().readText(), GitHubRelease::class.java)
                    403, 429 -> throw Exception("RATE_LIMIT")
                    else -> null
                }
            } catch (e: Exception) {
                if (e.message == "RATE_LIMIT") throw e
                null
            }
        }

    suspend fun getReleases(owner: String, repo: String, token: String? = null): List<GitHubRelease> =
        withContext(Dispatchers.IO) {
            try {
                val url = URL("https://api.github.com/repos/$owner/$repo/releases")
                val connection = url.openConnection() as HttpURLConnection
                if (token != null) connection.setRequestProperty("Authorization", "Bearer $token")
                when (connection.responseCode) {
                    200 -> gson.fromJson(connection.inputStream.bufferedReader().readText(), Array<GitHubRelease>::class.java).toList()
                    403, 429 -> throw Exception("RATE_LIMIT")
                    else -> emptyList()
                }
            } catch (e: Exception) {
                if (e.message == "RATE_LIMIT") throw e
                emptyList()
            }
        }

    suspend fun getReadme(owner: String, repo: String, token: String? = null): String? =
        withContext(Dispatchers.IO) {
            try {
                val url = URL("https://api.github.com/repos/$owner/$repo/readme")
                val connection = url.openConnection() as HttpURLConnection
                if (token != null) connection.setRequestProperty("Authorization", "Bearer $token")
                if (connection.responseCode == 200) {
                    val data = connection.inputStream.bufferedReader().readText()
                    val readmeMap = gson.fromJson(data, Map::class.java)
                    val content = readmeMap["content"] as? String ?: return@withContext null
                    val encoding = readmeMap["encoding"] as? String
                    if (encoding == "base64") {
                        String(android.util.Base64.decode(content, android.util.Base64.DEFAULT))
                    } else content
                } else null
            } catch (e: Exception) {
                null
            }
        }
}
