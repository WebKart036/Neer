package com.coolappstore.everlastingandroidtweak.utils

import android.content.Context
import android.os.Build
import android.os.Vibrator
import android.os.VibratorManager

/** Works on Android 11 (VibratorManager only exists on Android 12+). */
fun compatVibrator(context: Context): Vibrator =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
        (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
    else
        @Suppress("DEPRECATION")
        (context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
